КУБИК ПРЫГУН — Android-проект

Как собрать APK:
1. Установи Android Studio на компьютер.
2. Распакуй архив.
3. Открой папку KubikPrygun в Android Studio.
4. Дождись синхронизации Gradle.
5. Выбери Build → Build Bundle(s) / APK(s) → Build APK(s).
6. APK появится в app/build/outputs/apk/debug/app-debug.apk.

Игра работает в горизонтальном полноэкранном режиме.
Управление: кнопка «ПРЫЖОК» или касание игрового поля.
Рекорд сохраняется на устройстве.
